import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter-change-password',
  templateUrl: './recruiter-change-password.component.html',
  styleUrls: ['./recruiter-change-password.component.css']
})
export class RecruiterChangePasswordComponent {

}
