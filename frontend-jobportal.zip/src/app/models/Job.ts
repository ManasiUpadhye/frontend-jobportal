export class Job
{
    title :any;
    description :any;
    salary :any;
    experience :any;
    location :any;
    jobType :any;
    numberOfVacancy :any;
    categoryId :any;
    recruiterId :any;
    lastDate:any;

/*
    constructor(title :any,
        description :any,
        salary :any,
        experience :any,
        location :any,
        jobType :any,
        numberOfVacancy :any,
        categoryId:any,
        recruiterId:any
    )
   {
    this.title=title;
    this.description=description;
    this.salary=salary;
    this.experience=experience;
    this.location=location;
    this.jobType=jobType;
    this.numberOfVacancy=numberOfVacancy;
    this.categoryId=categoryId;
    this.recruiterId=recruiterId;
   }
   */

}