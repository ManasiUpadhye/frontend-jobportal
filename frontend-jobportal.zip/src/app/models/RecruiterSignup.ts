export class RecruiterSignup
{
    name:any;
    username:any;
    email:any;
    password:any;


    constructor( name:any,username:any,email:any,password:any)
    {
        this.email=email;
        this.name=name;
        this.password=password;
        this.username=username;
    }
}